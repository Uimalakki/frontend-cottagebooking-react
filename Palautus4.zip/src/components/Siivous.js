import {FormControlLabel, Checkbox} from '@material-ui/core';

function Siivous(props) {

    return (
            <div>
                <FormControlLabel
                    control={<Checkbox
                        onChange={(e) => {props.setSiivous(e.target.checked)}}
                        />}
                    label="Loppusiivous"
      />
            </div>
           )
}

export default Siivous;