import { useState, useEffect } from "react";
import Mokit from "./components/Mokit.js";
import Kesto from "./components/Kesto.js";
import Siivous from "./components/Siivous.js";
import {Container, Button, TextField} from '@material-ui/core';
import {Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions} from '@material-ui/core';

import DateFnsUtils from "@date-io/date-fns";
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import fiLocale from "date-fns/locale/fi";

function App() {

  const [mokit] = useState([
    {
      nimi: "Kuukkeli",
      hinta: 125
    },
    {
      nimi: "Metso",
      hinta: 150
    },
    {
      nimi: "Kaakkuri",
      hinta: 99
    },
    {
      nimi: "Sikotauti",
      hinta: 75
    }
  ]);

  const [naytaVaraus, setNaytaVaraus] = useState(false);
  const [valittuMokki, setValittu] = useState("");
  const [kesto, setKesto] = useState(1);
  const [siivous, setSiivous] = useState(false);
  const [nimi, setNimi] = useState("");
  const [onkoMokkiValittu, setOnkoMokkiValittu] = useState(false);
  const [selectedDate, handleDateChange] = useState(new Date());
  const [hinta, setHinta] = useState();

  const teeVaraus = () => {
    setNaytaVaraus(true);
  }

  const trueFalseSuomeksi = (syote) => {
    if(syote===true) {
      return ("Kyllä");
    } else {
      return ("Ei");
    }
  }

  const muunnaSelectedDate = () => {
    let kuukausi = selectedDate.getMonth() + 1;
    let paiva = selectedDate.getDate();
    let vuosi = selectedDate.getFullYear();
    console.log(selectedDate);

    return paiva + "." + kuukausi + "." + vuosi;
  }

  useEffect(() => {
    let siivouksenHinta = 0;
    if(siivous) {
      siivouksenHinta = 100;
    }
    setHinta(kesto * valittuMokki.hinta + siivouksenHinta);
  }, [valittuMokki, kesto, siivous])

  return (

    <Container>
      <h1>Lomamökkivaraus</h1>

      <Mokit 
        mokit={mokit} 
        setValittu={setValittu} 
        setOnkoMokkiValittu={setOnkoMokkiValittu}
        /><br />
      <Kesto setKesto={setKesto} kesto={kesto}/>
      
      <MuiPickersUtilsProvider utils={DateFnsUtils} locale={fiLocale}>
        <DatePicker 
          value={selectedDate} 
          format="dd/MM/yyyy"
          label="Aloituspvm"
          disablePast={true}
          onChange={handleDateChange}
          renderInput={(props) => <TextField {...props} />}
          />
      </MuiPickersUtilsProvider>
      
      <Siivous setSiivous={setSiivous}/>
      <TextField
        label="Varaajan nimi"
        placeholder="Etunimi Sukunimi"
        onChange={(e) => {setNimi(e.target.value)}}
        >
        
      </TextField><br/>
      <Button
        variant="contained"
        color="primary"
        onClick={ () => {teeVaraus()}}
        >Varaa mökki  
      </Button>

      {(hinta)
      ? <div className="alert alert-success">Kokonaishinta: {hinta}</div>
      : <div className="alert alert-warning">Loppuhinta ei ole vielä muodostunut</div>
      }
      

      <Dialog open={naytaVaraus} fullWidth={true}>
        <DialogTitle>Mökin varausvahvistus</DialogTitle>
        <DialogContent>
          {(onkoMokkiValittu)
          ? <DialogContentText>
              <div>Varaajan nimi: {nimi}</div> 
              <div>Mökin nimi: {valittuMokki.nimi}</div>
              <div>Alkamispäivämäärä: {muunnaSelectedDate()}</div>
              <div>Kesto: {kesto} päivää</div>
              <div>Kokonaishinta: {hinta}e</div>
              <div>Loppusiivous: {trueFalseSuomeksi(siivous)}</div>
            </DialogContentText>
          : <DialogContentText>
              <div>Mökkiä ei ole valittu!</div>  
            </DialogContentText>
          }
          
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            color="primary"
            onClick={ () => {setNaytaVaraus(false)}}
            >Ok
          </Button>
        </DialogActions>
      </Dialog>

    </Container>

    


  );
}

export default App;
